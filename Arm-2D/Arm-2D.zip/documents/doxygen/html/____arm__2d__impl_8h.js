var ____arm__2d__impl_8h =
[
    [ "ARM_2D_IMPL", "____arm__2d__impl_8h.html#a451aeef94e8d5bf76519f63cbca43493", null ],
    [ "ARM_2D_RUN_DEFAULT", "____arm__2d__impl_8h.html#ac0a8a9b5defd52c6b5251c9579e7f520", null ],
    [ "ARM_2D_TRY_ACCELERATION", "____arm__2d__impl_8h.html#a4b283d1d8cd28fdc1a93a1d7dd2e4f57", null ],
    [ "OP_CORE", "____arm__2d__impl_8h.html#a9f9d937dc5a6d79e26e25ebf55bbf679", null ],
    [ "this", "____arm__2d__impl_8h.html#a50383951d2a9d4f1a855b2cec5e03274", null ],
    [ "ARM_2D_CTRL", "____arm__2d__impl_8h.html#ac44741102f43d22321f1a8fae52be6ce", null ]
];