var arm__2d__features_8h =
[
    [ "__ARM_2D_CFG_DEFAULT_SUB_TASK_POOL_SIZE__", "arm__2d__features_8h.html#a849a39b45e7a5a22160515dda935ce09", null ],
    [ "__ARM_2D_CFG_FORCED_FIXED_POINT_TRANSFORM__", "arm__2d__features_8h.html#aa832111ac7c0cde008384bf6ff5f1fd8", null ],
    [ "__ARM_2D_CFG_SUPPORT_COLOUR_CHANNEL_ACCESS__", "arm__2d__features_8h.html#af7ee22ee8caba96056e63a8cd544031d", null ],
    [ "__ARM_2D_HAS_ANTI_ALIAS_TRANSFORM__", "arm__2d__features_8h.html#a24fb614359d977d784afbc821992f1c8", null ],
    [ "__ARM_2D_HAS_ASYNC__", "arm__2d__features_8h.html#a44b4f0ecafd8d5fb7de9f104d9321998", null ],
    [ "__ARM_2D_HAS_CDE__", "arm__2d__features_8h.html#a0ec19d4c98606a830a90ac39aac41a5e", null ],
    [ "__ARM_2D_HAS_DSP__", "arm__2d__features_8h.html#a2334c7acedcecf63d047be0a80d0290b", null ],
    [ "__ARM_2D_HAS_FPU__", "arm__2d__features_8h.html#a3ec54af19d1a150ab2ab66505aeae43b", null ],
    [ "__ARM_2D_HAS_HELIUM__", "arm__2d__features_8h.html#af53e5d3339794160c3b742536cc1783d", null ],
    [ "__ARM_2D_HAS_HELIUM_FLOAT__", "arm__2d__features_8h.html#a81fc3edf4e9b9ed199f262d2e8634d1a", null ],
    [ "__ARM_2D_HAS_HELIUM_INTEGER__", "arm__2d__features_8h.html#a06a44c9b3da26f938ebf0780fc693e9b", null ],
    [ "__ARM_2D_HAS_HW_ACC__", "arm__2d__features_8h.html#afc15611a43cb4dafc518b4948ab380f8", null ]
];