var ____arm__2d__math_8h =
[
    [ "_BV", "____arm__2d__math_8h.html#a94026a8222e1438f86fdb8c36b381903", null ],
    [ "ABS", "____arm__2d__math_8h.html#a996f7be338ccb40d1a2a5abc1ad61759", null ],
    [ "ARM_2D_ANGLE", "____arm__2d__math_8h.html#a86539c599e84cce7c62d447f2d411750", null ],
    [ "ARM_PIX_SCLTYP", "____arm__2d__math_8h.html#a5d272632a22e0803ab5b423328db9d46", null ],
    [ "MAX", "____arm__2d__math_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "MIN", "____arm__2d__math_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f", null ],
    [ "MUL_Q16", "____arm__2d__math_8h.html#a4ef0ba639a9c54743e098669d658998c", null ],
    [ "MULTFX", "____arm__2d__math_8h.html#a8229f0714afc303702b719820a158087", null ],
    [ "float16_t", "____arm__2d__math_8h.html#a49736383ceddf92e73a0620e13185b2f", null ]
];