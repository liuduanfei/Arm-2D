var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "a", "globals_func_a.html", null ]
];