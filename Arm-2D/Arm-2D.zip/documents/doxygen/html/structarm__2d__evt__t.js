var structarm__2d__evt__t =
[
    [ "fnHandler", "structarm__2d__evt__t.html#a276d348c59950c0663e28adfc4829c99", null ],
    [ "pTarget", "structarm__2d__evt__t.html#afaf83f02ebbc3a7fecbdddfa3eaca8f6", null ]
];