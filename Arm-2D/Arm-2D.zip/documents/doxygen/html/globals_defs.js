var globals_defs =
[
    [ "_", "globals_defs.html", null ],
    [ "a", "globals_defs_a.html", null ],
    [ "b", "globals_defs_b.html", null ],
    [ "c", "globals_defs_c.html", null ],
    [ "d", "globals_defs_d.html", null ],
    [ "e", "globals_defs_e.html", null ],
    [ "f", "globals_defs_f.html", null ],
    [ "g", "globals_defs_g.html", null ],
    [ "i", "globals_defs_i.html", null ],
    [ "l", "globals_defs_l.html", null ],
    [ "m", "globals_defs_m.html", null ],
    [ "o", "globals_defs_o.html", null ],
    [ "p", "globals_defs_p.html", null ],
    [ "r", "globals_defs_r.html", null ],
    [ "s", "globals_defs_s.html", null ],
    [ "t", "globals_defs_t.html", null ]
];