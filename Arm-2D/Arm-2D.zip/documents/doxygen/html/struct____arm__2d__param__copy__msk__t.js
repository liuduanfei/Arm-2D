var struct____arm__2d__param__copy__msk__t =
[
    [ "tDesMask", "struct____arm__2d__param__copy__msk__t.html#a844c8b0772ab3a9dc1422420ee3d137f", null ],
    [ "tSrcMask", "struct____arm__2d__param__copy__msk__t.html#a3989cd4060ebc60db41be427c8bfe7d9", null ]
];