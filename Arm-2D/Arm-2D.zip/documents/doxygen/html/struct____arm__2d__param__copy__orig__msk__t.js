var struct____arm__2d__param__copy__orig__msk__t =
[
    [ "tDesMask", "struct____arm__2d__param__copy__orig__msk__t.html#abbb1d92cee6f3df0bb46abbbe87cb626", null ],
    [ "tOrigMask", "struct____arm__2d__param__copy__orig__msk__t.html#adfea9cf3c41ca328aa0cf7aef8797eb4", null ]
];