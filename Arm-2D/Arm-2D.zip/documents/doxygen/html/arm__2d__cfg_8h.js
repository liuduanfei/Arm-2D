var arm__2d__cfg_8h =
[
    [ "__ARM_2D_CFG_SUPPORT_COLOUR_CHANNEL_ACCESS__", "arm__2d__cfg_8h.html#af7ee22ee8caba96056e63a8cd544031d", null ],
    [ "__ARM_2D_HAS_ANTI_ALIAS_TRANSFORM__", "arm__2d__cfg_8h.html#a24fb614359d977d784afbc821992f1c8", null ],
    [ "__ARM_2D_HAS_ASYNC__", "arm__2d__cfg_8h.html#a44b4f0ecafd8d5fb7de9f104d9321998", null ]
];