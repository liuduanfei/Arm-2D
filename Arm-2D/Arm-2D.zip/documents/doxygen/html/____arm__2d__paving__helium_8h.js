var ____arm__2d__paving__helium_8h =
[
    [ "CMP_CL_MSK", "____arm__2d__paving__helium_8h.html#a1881c58e6c13b58d0b7d7a18a631d5c9", null ],
    [ "IS_PAVING_DIRECT_LOAD_PATTERN", "____arm__2d__paving__helium_8h.html#af889be4d0439f1db19c1e02aca6963b1", null ],
    [ "IS_PAVING_X_MIRROR_LOAD_PATTERN", "____arm__2d__paving__helium_8h.html#a5903002af84a4c9c4c7333bf5776372b", null ],
    [ "IS_PAVING_XY_MIRROR_LOAD_PATTERN", "____arm__2d__paving__helium_8h.html#afbf3a65c7f7dd7fddd2e3720141be82d", null ],
    [ "IS_PAVING_Y_MIRROR_LOAD_PATTERN", "____arm__2d__paving__helium_8h.html#af7bd05089495134c09cebb55601ea976", null ],
    [ "LOAD_SRC_DIRECT_16", "____arm__2d__paving__helium_8h.html#a2d54828dcdaeecfd790417b941a52212", null ],
    [ "LOAD_SRC_DIRECT_32", "____arm__2d__paving__helium_8h.html#a6be833173f8216880262603ad58342a7", null ],
    [ "LOAD_SRC_DIRECT_8", "____arm__2d__paving__helium_8h.html#addfb5d002955f2aaaa4f625a382a6094", null ],
    [ "LOAD_SRC_X_MIRROR_16", "____arm__2d__paving__helium_8h.html#ab93b1d05838af7ce1536e08c64ac92e0", null ],
    [ "LOAD_SRC_X_MIRROR_32", "____arm__2d__paving__helium_8h.html#a9d5d767528d31c10704c5ed631cdb95f", null ],
    [ "LOAD_SRC_X_MIRROR_8", "____arm__2d__paving__helium_8h.html#a847e58844c5cf18614a1ced92c5efc0d", null ],
    [ "SETUP_MIRROR_COPY_16", "____arm__2d__paving__helium_8h.html#a1143d22209a37ec736ee112ba68bf347", null ],
    [ "SETUP_MIRROR_COPY_32", "____arm__2d__paving__helium_8h.html#a06a499b24562cadbf731a09c50d5ad8d", null ],
    [ "SETUP_MIRROR_COPY_8", "____arm__2d__paving__helium_8h.html#aba18a21253bc71e6688ed32210ef294a", null ]
];