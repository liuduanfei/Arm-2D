var arm__2d__draw_8c =
[
    [ "ARM_2D_OP_DRAW_PATTERN_C8BIT", "arm__2d__draw_8c.html#a9d2450c4ee3c0f3e5c20f6df17950937", null ],
    [ "ARM_2D_OP_DRAW_PATTERN_RGB16", "arm__2d__draw_8c.html#a6b32c1cb09c23332524172b7749cf32c", null ],
    [ "ARM_2D_OP_DRAW_PATTERN_RGB32", "arm__2d__draw_8c.html#a31a5c19322c2e0e43a55bd2671b0f1f1", null ],
    [ "ARM_2D_OP_DRAW_POINT_C8BIT", "arm__2d__draw_8c.html#a593fadbebb0233be184574b13dfebdd1", null ],
    [ "ARM_2D_OP_DRAW_POINT_RGB16", "arm__2d__draw_8c.html#abf4c815c546769451bec088c1dbca221", null ],
    [ "ARM_2D_OP_DRAW_POINT_RGB32", "arm__2d__draw_8c.html#a1db08c7c135dc98874902dea37217a29", null ],
    [ "ARM_2D_OP_FILL_COLOUR_C8BIT", "arm__2d__draw_8c.html#a9a1bc4145892aeaf90961fd3d4bb3ea1", null ],
    [ "ARM_2D_OP_FILL_COLOUR_RGB16", "arm__2d__draw_8c.html#af923ff8b6c24e9cfd0b51854491158d1", null ],
    [ "ARM_2D_OP_FILL_COLOUR_RGB32", "arm__2d__draw_8c.html#a302b17d77de09ccd3da2f91fa2d1801a", null ]
];