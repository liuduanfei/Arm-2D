var arm__2d_8h =
[
    [ "arm_2d_runtime_feature_t", "structarm__2d__runtime__feature__t.html", "structarm__2d__runtime__feature__t" ],
    [ "arm_2d_version_t", "structarm__2d__version__t.html", "structarm__2d__version__t" ],
    [ "ARM_2D_VERISON", "arm__2d_8h.html#a11b2dbdafc85d9d678e52447cc25f9ac", null ],
    [ "ARM_2D_VERSION_MAJOR", "arm__2d_8h.html#aa1a520634c974866fb98044c63143532", null ],
    [ "ARM_2D_VERSION_MINOR", "arm__2d_8h.html#a17fea46439a9f655a68d9b186838163e", null ],
    [ "ARM_2D_VERSION_PATCH", "arm__2d_8h.html#a84adc455ac15b1574d66130d661dbd7e", null ],
    [ "ARM_2D_VERSION_STR", "arm__2d_8h.html#a717a4db05af2c6d8e4ee171f6ba53d52", null ],
    [ "arm_2d_get_default_frame_buffer", "arm__2d_8h.html#aa0f5857c97450feeb79b3983dd1a950b", null ],
    [ "arm_2d_get_op_status", "arm__2d_8h.html#a78ba01fb790d0a43878499dcb2639e0d", null ],
    [ "arm_2d_init", "arm__2d_8h.html#ae417897e7d7186b294c0ff3468102276", null ],
    [ "arm_2d_op_wait_async", "arm__2d_8h.html#a129e2a7110847b0fd22eeb6351205989", null ],
    [ "arm_2d_set_default_frame_buffer", "arm__2d_8h.html#a42407a7eebceade2349b1309bdf78b48", null ],
    [ "arm_2d_set_user_param", "arm__2d_8h.html#af435aa9cb213d9c2d39fb34ef02641ed", null ],
    [ "arm_2d_task", "arm__2d_8h.html#a14a09993e474bef1266e2572146b8341", null ],
    [ "ARM_2D_RUNTIME_FEATURE", "arm__2d_8h.html#ae30937777f3c67e2418c9c26c76fb501", null ],
    [ "ARM_2D_VERSION", "arm__2d_8h.html#a3cef1eb288e3529dab7e441cc769e1e2", null ]
];