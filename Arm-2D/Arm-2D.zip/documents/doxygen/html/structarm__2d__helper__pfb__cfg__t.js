var structarm__2d__helper__pfb__cfg__t =
[
    [ "bDisableDynamicFPBSize", "structarm__2d__helper__pfb__cfg__t.html#aba981bed04008932aef68ad64d53ade8", null ],
    [ "bDoNOTUpdateDefaultFrameBuffer", "structarm__2d__helper__pfb__cfg__t.html#a7f2659e2d2d91903f7c7ddb2e6601665", null ],
    [ "bSwapRGB16", "structarm__2d__helper__pfb__cfg__t.html#a5eae45d5bd62c3fc6b332fae8fe26c9a", null ],
    [ "Dependency", "structarm__2d__helper__pfb__cfg__t.html#a65ec336911098eaed7b2ac60038dda6e", null ],
    [ "FrameBuffer", "structarm__2d__helper__pfb__cfg__t.html#aa24ae9a0fa4971e27e32942bf1399d8a", null ],
    [ "hwPFBNum", "structarm__2d__helper__pfb__cfg__t.html#a9b01913bdd6fe9d2a2b539b4ff977133", null ],
    [ "ptPFBs", "structarm__2d__helper__pfb__cfg__t.html#a48ff609d75c80432423b4a537b210565", null ],
    [ "tDisplayArea", "structarm__2d__helper__pfb__cfg__t.html#adc4ca6df76cda6514cff8a4cec3918ca", null ],
    [ "tFrameSize", "structarm__2d__helper__pfb__cfg__t.html#a37d9ea4a7da037ac29136a17b0e351b8", null ],
    [ "wBufferSize", "structarm__2d__helper__pfb__cfg__t.html#a373f82efd20baa85bccf7755f4ef8f99", null ]
];