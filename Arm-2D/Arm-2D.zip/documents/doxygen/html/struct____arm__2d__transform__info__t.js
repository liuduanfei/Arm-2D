var struct____arm__2d__transform__info__t =
[
    [ "chColour", "struct____arm__2d__transform__info__t.html#a62b5648007fbcca51408d2140ab69494", null ],
    [ "fAngle", "struct____arm__2d__transform__info__t.html#a598a27b28a4c799378c9b10c4a792f75", null ],
    [ "fScale", "struct____arm__2d__transform__info__t.html#afe43ae7c569abd89f499db003873b915", null ],
    [ "hwColour", "struct____arm__2d__transform__info__t.html#a1813c39333d06c4ed6057470c9338891", null ],
    [ "Mask", "struct____arm__2d__transform__info__t.html#afa5754bf23d20fdb4490302cbfdc449f", null ],
    [ "tCenter", "struct____arm__2d__transform__info__t.html#af28938e370300a48f60257df2ff20241", null ],
    [ "wColour", "struct____arm__2d__transform__info__t.html#a815a057c626189635158977508e07213", null ]
];