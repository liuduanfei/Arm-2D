var searchData=
[
  ['declare_5ftile_0',['declare_tile',['../arm__2d__helper_8h.html#a8ff1a2d6d72b77d9af31174201f62949',1,'arm_2d_helper.h']]],
  ['decr_5fy_5fdir_1',['DECR_Y_DIR',['../____arm__2d__paving_8h.html#a272c88eb2723a5f77e3e440248554300',1,'__arm_2d_paving.h']]],
  ['dependency_2',['Dependency',['../structarm__2d__helper__pfb__cfg__t.html#a65ec336911098eaed7b2ac60038dda6e',1,'arm_2d_helper_pfb_cfg_t']]],
  ['dimof_3',['dimof',['../arm__2d__utils_8h.html#a7b6c484887a402bba1af11b457264553',1,'arm_2d_utils.h']]],
  ['readme_2emd_4',['README.md',['../documents_2README_8md.html',1,'']]]
];
