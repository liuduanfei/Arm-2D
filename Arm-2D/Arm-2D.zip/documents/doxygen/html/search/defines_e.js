var searchData=
[
  ['setup_5fdirect_5fcopy_5f16_0',['SETUP_DIRECT_COPY_16',['../____arm__2d__paving_8h.html#aa4966a08050140e3d7458294caf3659d',1,'__arm_2d_paving.h']]],
  ['setup_5fdirect_5fcopy_5f32_1',['SETUP_DIRECT_COPY_32',['../____arm__2d__paving_8h.html#ad5b3ec5099d74000130066acf650dc6c',1,'__arm_2d_paving.h']]],
  ['setup_5fdirect_5fcopy_5f8_2',['SETUP_DIRECT_COPY_8',['../____arm__2d__paving_8h.html#aa2bfe985bd4a6304c13c8f272c27feda',1,'__arm_2d_paving.h']]],
  ['setup_5fmirror_5fcopy_5f16_3',['SETUP_MIRROR_COPY_16',['../____arm__2d__paving_8h.html#a1143d22209a37ec736ee112ba68bf347',1,'SETUP_MIRROR_COPY_16():&#160;__arm_2d_paving.h'],['../____arm__2d__paving__helium_8h.html#a1143d22209a37ec736ee112ba68bf347',1,'SETUP_MIRROR_COPY_16():&#160;__arm_2d_paving_helium.h']]],
  ['setup_5fmirror_5fcopy_5f32_4',['SETUP_MIRROR_COPY_32',['../____arm__2d__paving_8h.html#a06a499b24562cadbf731a09c50d5ad8d',1,'SETUP_MIRROR_COPY_32():&#160;__arm_2d_paving.h'],['../____arm__2d__paving__helium_8h.html#a06a499b24562cadbf731a09c50d5ad8d',1,'SETUP_MIRROR_COPY_32():&#160;__arm_2d_paving_helium.h']]],
  ['setup_5fmirror_5fcopy_5f8_5',['SETUP_MIRROR_COPY_8',['../____arm__2d__paving_8h.html#aba18a21253bc71e6688ed32210ef294a',1,'SETUP_MIRROR_COPY_8():&#160;__arm_2d_paving.h'],['../____arm__2d__paving__helium_8h.html#aba18a21253bc71e6688ed32210ef294a',1,'SETUP_MIRROR_COPY_8():&#160;__arm_2d_paving_helium.h']]]
];
