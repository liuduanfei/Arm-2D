var searchData=
[
  ['background_0',['Background',['../structarm__2d__op__drw__patn__t.html#afec234661a87fca7442acb76fb3b44e2',1,'arm_2d_op_drw_patn_t']]],
  ['bbigendian_1',['bBigEndian',['../unionarm__2d__color__info__t.html#a2df74bcca8eee55fafc964e4ac4ddd37',1,'arm_2d_color_info_t']]],
  ['bclipregion_2',['bClipRegion',['../arm__2d__tile_8h.html#a7dc372aa5fc05c99cc23552860121efc',1,'arm_2d_tile.h']]],
  ['bdisabledynamicfpbsize_3',['bDisableDynamicFPBSize',['../structarm__2d__helper__pfb__cfg__t.html#aba981bed04008932aef68ad64d53ade8',1,'arm_2d_helper_pfb_cfg_t']]],
  ['bdonotupdatedefaultframebuffer_4',['bDoNOTUpdateDefaultFrameBuffer',['../structarm__2d__helper__pfb__cfg__t.html#a7f2659e2d2d91903f7c7ddb2e6601665',1,'arm_2d_helper_pfb_cfg_t']]],
  ['bhasalpha_5',['bHasAlpha',['../unionarm__2d__color__info__t.html#ad8ba6acfc19fcbdc93ced722ad8c1b5b',1,'arm_2d_color_info_t']]],
  ['bioerror_6',['bIOError',['../unionarm__2d__op__status__t.html#a05d54ffa9a11994ea45ef47cc0748157',1,'arm_2d_op_status_t']]],
  ['bisbusy_7',['bIsBusy',['../unionarm__2d__op__status__t.html#a3ae8d10f4e4edc70da8ce05be5e3aa58',1,'arm_2d_op_status_t']]],
  ['bisnewframe_8',['bIsNewFrame',['../structarm__2d__pfb__t.html#a4b9c82f196be65325800ed8a5d1fd0d3',1,'arm_2d_pfb_t']]],
  ['bopcpl_9',['bOpCpl',['../unionarm__2d__op__status__t.html#ad557aa1a994625b051f6a27aa0bd5a2a',1,'arm_2d_op_status_t']]],
  ['bottom_5fto_5ftop_10',['BOTTOM_TO_TOP',['../____arm__2d__paving_8h.html#a4f13024d3542bbe924c301dae7898441',1,'__arm_2d_paving.h']]],
  ['bswaprgb16_11',['bSwapRGB16',['../structarm__2d__helper__pfb__cfg__t.html#a5eae45d5bd62c3fc6b332fae8fe26c9a',1,'arm_2d_helper_pfb_cfg_t']]]
];
