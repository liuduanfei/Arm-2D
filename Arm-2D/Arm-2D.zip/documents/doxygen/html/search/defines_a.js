var searchData=
[
  ['max_0',['MAX',['../____arm__2d__math_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f',1,'__arm_2d_math.h']]],
  ['min_1',['MIN',['../____arm__2d__math_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'__arm_2d_math.h']]],
  ['mul_5fq16_2',['MUL_Q16',['../____arm__2d__math_8h.html#a4ef0ba639a9c54743e098669d658998c',1,'__arm_2d_math.h']]],
  ['multfx_3',['MULTFX',['../____arm__2d__math_8h.html#a8229f0714afc303702b719820a158087',1,'__arm_2d_math.h']]]
];
