var searchData=
[
  ['arm_5f2d_5fget_5fdefault_5fframe_5fbuffer_0',['arm_2d_get_default_frame_buffer',['../arm__2d_8h.html#aa0f5857c97450feeb79b3983dd1a950b',1,'arm_2d.h']]],
  ['arm_5f2d_5fget_5fop_5fstatus_1',['arm_2d_get_op_status',['../arm__2d_8h.html#a78ba01fb790d0a43878499dcb2639e0d',1,'arm_2d.h']]],
  ['arm_5f2d_5fhelper_5fperf_5fcounter_5fstart_2',['arm_2d_helper_perf_counter_start',['../arm__2d__helper__pfb_8c.html#aa1f9287e84142b37010af6e9135b9b44',1,'arm_2d_helper_pfb.c']]],
  ['arm_5f2d_5fhelper_5fperf_5fcounter_5fstop_3',['arm_2d_helper_perf_counter_stop',['../arm__2d__helper__pfb_8c.html#a271a5660dffcc0e3530422a1f9ce9961',1,'arm_2d_helper_pfb.c']]],
  ['arm_5f2d_5fhelper_5fpfb_5ftask_4',['arm_2d_helper_pfb_task',['../arm__2d__helper__pfb_8c.html#ab2cec999a9abbf7ec42bed4352a17b88',1,'arm_2d_helper_pfb.c']]],
  ['arm_5f2d_5finit_5',['arm_2d_init',['../arm__2d_8h.html#ae417897e7d7186b294c0ff3468102276',1,'arm_2d_init(void):&#160;arm_2d.c'],['../arm__2d_8c.html#ae417897e7d7186b294c0ff3468102276',1,'arm_2d_init(void):&#160;arm_2d.c']]],
  ['arm_5f2d_5fop_5fwait_5fasync_6',['arm_2d_op_wait_async',['../arm__2d_8h.html#a129e2a7110847b0fd22eeb6351205989',1,'arm_2d.h']]],
  ['arm_5f2d_5fset_5fdefault_5fframe_5fbuffer_7',['arm_2d_set_default_frame_buffer',['../arm__2d_8h.html#a42407a7eebceade2349b1309bdf78b48',1,'arm_2d.h']]],
  ['arm_5f2d_5fset_5fuser_5fparam_8',['arm_2d_set_user_param',['../arm__2d_8h.html#af435aa9cb213d9c2d39fb34ef02641ed',1,'arm_2d.h']]],
  ['arm_5f2d_5ftask_9',['arm_2d_task',['../arm__2d_8h.html#a14a09993e474bef1266e2572146b8341',1,'arm_2d.h']]]
];
