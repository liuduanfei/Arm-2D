var searchData=
[
  ['offsetof_0',['offsetof',['../arm__2d__utils_8h.html#a8a4dba3eaaa8e7d90abb2eff93092042',1,'arm_2d_utils.h']]],
  ['op_5fcore_1',['OP_CORE',['../____arm__2d__impl_8h.html#a9f9d937dc5a6d79e26e25ebf55bbf679',1,'__arm_2d_impl.h']]],
  ['origin_2',['Origin',['../structarm__2d__op__trans__t.html#af2b2b053c884f33569f865dd5218824b',1,'arm_2d_op_trans_t::Origin()'],['../structarm__2d__op__trans__opa__t.html#a98ce33736f0a173d67ea9e8b17495682',1,'arm_2d_op_trans_opa_t::Origin()'],['../structarm__2d__op__trans__msk__t.html#a7c7fa5c749f2ecc7ee91f70d66ca98ec',1,'arm_2d_op_trans_msk_t::Origin()'],['../structarm__2d__op__trans__msk__opa__t.html#a0f13c0a2215183d35e0ab40139e29a3a',1,'arm_2d_op_trans_msk_opa_t::Origin()'],['../structarm__2d__op__src__orig__t.html#aa5a16739f3423be00c48ce5cfb3b899a',1,'arm_2d_op_src_orig_t::Origin()'],['../structarm__2d__op__src__orig__msk__t.html#a7411ec61e13d4c9ec0cb77e08a08e313',1,'arm_2d_op_src_orig_msk_t::Origin()']]]
];
