var searchData=
[
  ['fast_5fatan_5ff32_5f1_0',['FAST_ATAN_F32_1',['../arm__2d__transform_8c.html#ac41f1aec57abc106e2ddbd4f5d75a0f4',1,'arm_2d_transform.c']]]
];
