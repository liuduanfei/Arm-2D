var searchData=
[
  ['get_5ftile_5fbuffer_5fpixel_5fcount_0',['get_tile_buffer_pixel_count',['../arm__2d__helper_8h.html#a0f6932c29834326e8499ecad35dd034c',1,'arm_2d_helper.h']]],
  ['get_5ftile_5fbuffer_5fsize_1',['get_tile_buffer_size',['../arm__2d__helper_8h.html#a75ac3fb5f86d86d11e972f47d109bfcd',1,'arm_2d_helper.h']]]
];
