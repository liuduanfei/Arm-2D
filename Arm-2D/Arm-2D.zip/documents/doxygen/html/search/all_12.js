var searchData=
[
  ['u3coloursz_0',['u3ColourSZ',['../unionarm__2d__color__info__t.html#a367a79439643b5f63b9153534f082c51',1,'arm_2d_color_info_t']]],
  ['u3variant_1',['u3Variant',['../unionarm__2d__color__info__t.html#ae1e4a766120db54d6f748954e132f8ad',1,'arm_2d_color_info_t']]],
  ['u4subtaskcount_2',['u4SubTaskCount',['../unionarm__2d__op__status__t.html#ac84b47cad2d95d7c26d62a2a7d08f5a7',1,'arm_2d_op_status_t']]],
  ['u5b_3',['u5B',['../unionarm__2d__color__rgb565__t.html#aa5f7b495138359990ad6dc2b6525e836',1,'arm_2d_color_rgb565_t']]],
  ['u5r_4',['u5R',['../unionarm__2d__color__rgb565__t.html#ace20e3dd2919be7c014f329d07dc41dd',1,'arm_2d_color_rgb565_t']]],
  ['u6g_5',['u6G',['../unionarm__2d__color__rgb565__t.html#a500711842045c78f14d30e0fb679c740',1,'arm_2d_color_rgb565_t']]],
  ['u8a_6',['u8A',['../unionarm__2d__color__rgba8888__t.html#abf716ea760145003e1846f85e1bfd55f',1,'arm_2d_color_rgba8888_t::u8A()'],['../unionarm__2d__color__ccca8888__t.html#afcf9ae24241cb87cdc2dc393a8a8f120',1,'arm_2d_color_ccca8888_t::u8A()'],['../unionarm__2d__color__accc8888__t.html#a2a53508fcfb4f5c98728eb76f7012eea',1,'arm_2d_color_accc8888_t::u8A()']]],
  ['u8b_7',['u8B',['../unionarm__2d__color__rgba8888__t.html#a02e9f20da2a432b14668de85ba4d577b',1,'arm_2d_color_rgba8888_t::u8B()'],['../unionarm__2d__color__rgb888__t.html#ae76a9dd94a89817b9d38c9ad9b6e3e7b',1,'arm_2d_color_rgb888_t::u8B()']]],
  ['u8c_8',['u8C',['../unionarm__2d__color__ccca8888__t.html#a1c2a64512d8b6b50b04dc1680178a442',1,'arm_2d_color_ccca8888_t::u8C()'],['../unionarm__2d__color__accc8888__t.html#a8d7776a19c249a897a128f18e4d8d4d8',1,'arm_2d_color_accc8888_t::u8C()'],['../unionarm__2d__color__cccn888__t.html#ab7cbd6cca47dcfbf8b27e23030ffefc5',1,'arm_2d_color_cccn888_t::u8C()'],['../unionarm__2d__color__nccc888__t.html#a32bd3ae7f9ba188bc73fc78f6c6826ca',1,'arm_2d_color_nccc888_t::u8C()']]],
  ['u8g_9',['u8G',['../unionarm__2d__color__rgba8888__t.html#aa8a6f9f73a6be939c196d62bc4c04e20',1,'arm_2d_color_rgba8888_t::u8G()'],['../unionarm__2d__color__rgb888__t.html#ab70cbc8bc72eaf044d7468410e28b37e',1,'arm_2d_color_rgb888_t::u8G()']]],
  ['u8r_10',['u8R',['../unionarm__2d__color__rgba8888__t.html#a02ab32c619169a4adcc0abd364297087',1,'arm_2d_color_rgba8888_t::u8R()'],['../unionarm__2d__color__rgb888__t.html#a93dc9e7c2e4024d3ca8b13bc36b52fe1',1,'arm_2d_color_rgb888_t::u8R()']]]
];
