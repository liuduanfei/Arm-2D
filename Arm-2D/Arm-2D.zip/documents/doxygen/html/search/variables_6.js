var searchData=
[
  ['has_5fdedicated_5fthread_5ffor_5f2d_5ftask_0',['HAS_DEDICATED_THREAD_FOR_2D_TASK',['../structarm__2d__runtime__feature__t.html#a43ace7cfacc269488ec92483ab3beaca',1,'arm_2d_runtime_feature_t']]],
  ['hwbackcolour_1',['hwBackColour',['../arm__2d__draw_8h.html#a4cafe2ef15d3d61f7e44b284aed642a4',1,'arm_2d_draw.h']]],
  ['hwcolour_2',['hwColour',['../structarm__2d__op__alpha__cl__key__t.html#a13d5bfa95c504d60a781f857e70d3e83',1,'arm_2d_op_alpha_cl_key_t::hwColour()'],['../structarm__2d__op__fill__cl__msk__t.html#a8f51160cb6b6b17c235ec60e5f918924',1,'arm_2d_op_fill_cl_msk_t::hwColour()'],['../structarm__2d__op__alpha__fill__cl__msk__opc__t.html#a4a43f9fc8469595f41f77d009c591749',1,'arm_2d_op_alpha_fill_cl_msk_opc_t::hwColour()'],['../structarm__2d__op__fill__cl__opc__t.html#a56266b27bccac4adfdaa67dea166b85c',1,'arm_2d_op_fill_cl_opc_t::hwColour()'],['../structarm__2d__op__fill__cl__t.html#a342c7bf6eaf66299e367064640300ab5',1,'arm_2d_op_fill_cl_t::hwColour()'],['../structarm__2d__op__drw__patn__t.html#ae1c307c362a307faa81d3084a4351748',1,'arm_2d_op_drw_patn_t::hwColour()'],['../structarm__2d__op__cp__cl__key__t.html#a3175ae6863b1ea64fedfe631f2e678b7',1,'arm_2d_op_cp_cl_key_t::hwColour()'],['../arm__2d__draw_8h.html#ad889ecad4b4b237b36815d51803d1c4d',1,'hwColour():&#160;arm_2d_draw.h']]],
  ['hwfillcolour_3',['hwFillColour',['../arm__2d__transform_8h.html#ad7c717d90e4e47c270f2128651d95e44',1,'arm_2d_transform.h']]],
  ['hwforecolour_4',['hwForeColour',['../arm__2d__draw_8h.html#a54672d95c859c757795d775352173728',1,'arm_2d_draw.h']]],
  ['hwmaskcolour_5',['hwMaskColour',['../arm__2d__tile_8h.html#a8819ce4bd172f0ddde9ca10cc8cadbf0',1,'arm_2d_tile.h']]],
  ['hwpfbnum_6',['hwPFBNum',['../structarm__2d__helper__pfb__cfg__t.html#a9b01913bdd6fe9d2a2b539b4ff977133',1,'arm_2d_helper_pfb_cfg_t']]]
];
