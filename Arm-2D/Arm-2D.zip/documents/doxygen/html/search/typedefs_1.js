var searchData=
[
  ['float16_5ft_0',['float16_t',['../____arm__2d__math_8h.html#a49736383ceddf92e73a0620e13185b2f',1,'__arm_2d_math.h']]]
];
