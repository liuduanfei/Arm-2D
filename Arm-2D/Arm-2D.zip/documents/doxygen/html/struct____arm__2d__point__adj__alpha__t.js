var struct____arm__2d__point__adj__alpha__t =
[
    [ "chAlpha", "struct____arm__2d__point__adj__alpha__t.html#a14c2d3f77c4b3c76fee665d1126841ef", null ],
    [ "tMatrix", "struct____arm__2d__point__adj__alpha__t.html#afb5aaa52d4e383f179abe647f8cbb3cc", null ],
    [ "tOffset", "struct____arm__2d__point__adj__alpha__t.html#ac0e69ea0f04748754a631e7899ebb620", null ]
];