var structarm__2d__helper__draw__evt__t =
[
    [ "fnHandler", "structarm__2d__helper__draw__evt__t.html#a3e8dc622864ff93cd77e5d656268f7ff", null ],
    [ "pTarget", "structarm__2d__helper__draw__evt__t.html#aa7d6bab2668f99af677be69e289f59b0", null ]
];