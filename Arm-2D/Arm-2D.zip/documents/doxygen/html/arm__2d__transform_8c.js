var arm__2d__transform_8c =
[
    [ "EPS_ATAN2", "arm__2d__transform_8c.html#ac45b3b5e459e7f42272921180e72d037", null ],
    [ "FAST_ATAN_F32_1", "arm__2d__transform_8c.html#ac41f1aec57abc106e2ddbd4f5d75a0f4", null ],
    [ "TO_Q16", "arm__2d__transform_8c.html#ae4d6b00f640338228c69e4978ca10167", null ],
    [ "ARM_2D_OP_TRANSFORM_CCCN888", "arm__2d__transform_8c.html#abfe25527c148bf09da32f1a3136dd135", null ],
    [ "ARM_2D_OP_TRANSFORM_GRAY8", "arm__2d__transform_8c.html#a8c119784229c6faad9232d53421e9cc2", null ],
    [ "ARM_2D_OP_TRANSFORM_RGB565", "arm__2d__transform_8c.html#a2ad78854bb79598f853c7f75783cf6e1", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_OPACITY_CCCN888", "arm__2d__transform_8c.html#aba0d623307f37cc43f1d11b7560c1664", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_OPACITY_GRAY8", "arm__2d__transform_8c.html#a13769e17e1ca190770e16f23ac320360", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_OPACITY_RGB565", "arm__2d__transform_8c.html#a294ced4bc5ad4c50d64d1633900882fb", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_SRC_MSK_AND_OPACITY_CCCN888", "arm__2d__transform_8c.html#a4a2272d482bf6c3784930975bc99a349", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_SRC_MSK_AND_OPACITY_GRAY8", "arm__2d__transform_8c.html#a2f0e8df2479833d6be5e4b4a16906133", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_SRC_MSK_AND_OPACITY_RGB565", "arm__2d__transform_8c.html#a335dc2ab781da2964094255cade2c6a0", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_SRC_MSK_CCCN888", "arm__2d__transform_8c.html#a342bb795c009b87eb3badb04d3d47828", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_SRC_MSK_GRAY8", "arm__2d__transform_8c.html#a0c45e316e2d4030ea633cbd527d7baad", null ],
    [ "ARM_2D_OP_TRANSFORM_WITH_SRC_MSK_RGB565", "arm__2d__transform_8c.html#acaca737de98172486cc771b74ea20fdd", null ]
];