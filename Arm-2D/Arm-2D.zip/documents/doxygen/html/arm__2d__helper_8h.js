var arm__2d__helper_8h =
[
    [ "arm_2d_align_centre", "arm__2d__helper_8h.html#aaad43aef0ad2472379061137f374b72c", null ],
    [ "declare_tile", "arm__2d__helper_8h.html#a8ff1a2d6d72b77d9af31174201f62949", null ],
    [ "get_tile_buffer_pixel_count", "arm__2d__helper_8h.html#a0f6932c29834326e8499ecad35dd034c", null ],
    [ "get_tile_buffer_size", "arm__2d__helper_8h.html#a75ac3fb5f86d86d11e972f47d109bfcd", null ],
    [ "implement_tile", "arm__2d__helper_8h.html#ae7719d32fd484c295076b9f3e8593aab", null ]
];